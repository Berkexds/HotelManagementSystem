CREATE TABLE Customer (
 CustomerID INT PRIMARY KEY,
 Phone VARCHAR(20),
 EmailAddress VARCHAR(100),
 Name VARCHAR(100),
 DateOfBirth DATE
);
CREATE TABLE Room (
 RoomID INT PRIMARY KEY,
 RoomStatus VARCHAR(50),
 Description TEXT,
 PricePerNight DECIMAL(10,2),
 RoomType VARCHAR(50)
);
CREATE TABLE Payment (
 PaymentID INT PRIMARY KEY,
 PaymentMethod VARCHAR(50),
 PaymentStatus VARCHAR(50),
 Amount DECIMAL(10,2),
 PaymentDate DATE,
 CustomerID INT,
 FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);
CREATE TABLE Reservation (
 ReservationID INT PRIMARY KEY,
 ReservationStatus VARCHAR(50),
 NumberOfPeople INT,
 Date DATE,
 PaymentID INT,
 RoomID INT,
 CustomerID INT,
 FOREIGN KEY (PaymentID) REFERENCES Payment(PaymentID),
 FOREIGN KEY (RoomID) REFERENCES Room(RoomID),
 FOREIGN KEY (CustomerID) REFERENCES Customer(CustomerID)
);
CREATE TABLE Feedback (
 ReservationID INT PRIMARY KEY, -- Assuming 1 feedback per reservation
 DateOfFeedback DATE,
 AnonymityStatus BOOLEAN,
 ManagementResponse TEXT,
 Rating INT,
 Comments TEXT,
 FOREIGN KEY (ReservationID) REFERENCES Reservation(ReservationID)
);
CREATE TABLE Employee (
 EmployeeID INT PRIMARY KEY,
 Title VARCHAR(50),
 Salary DECIMAL(10,2),
 DateOfHiring DATE,
 WorkingHours VARCHAR(50),
 ManagerID INT,
 FOREIGN KEY (ManagerID) REFERENCES Employee(EmployeeID)
);
CREATE TABLE Organize (
 ReservationID INT,
 EmployeeID INT,
 PRIMARY KEY (ReservationID, EmployeeID),
 FOREIGN KEY (ReservationID) REFERENCES Reservation(ReservationID),
 FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);
CREATE TABLE HasAccess (
 RoomID INT,
 EmployeeID INT,
 PRIMARY KEY (RoomID, EmployeeID),
 FOREIGN KEY (RoomID) REFERENCES Room(RoomID),
 FOREIGN KEY (EmployeeID) REFERENCES Employee(EmployeeID)
);