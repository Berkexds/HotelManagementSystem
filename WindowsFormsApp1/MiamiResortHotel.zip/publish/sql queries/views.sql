CREATE VIEW GuestReservationOverview AS
SELECT
 r.ReservationID,
 r.CustomerID,
 c.Name,
 r.RoomID,
 r.ReservationStatus,
 r.CheckIn,
 r.CheckOut,
 p.Amount,
 p.PaymentStatus
FROM Reservation r
JOIN Customer c ON r.CustomerID = c.CustomerID
JOIN Payment p ON r.PaymentID = p.PaymentID;
CREATE VIEW RoomInventoryStatus AS
SELECT
 RoomID,
 RoomStatus,
 RoomType,
 PricePerNight,
 Description
FROM Room;
CREATE VIEW ManagerCustomerOverview AS
SELECT
 r.ReservationID,
 c.Name,
 c.EmailAddress,
 c.Phone,
 r.RoomID,
 r.CheckIn,
 r.CheckOut
FROM Reservation r
JOIN Customer c ON r.CustomerID = c.CustomerID;
CREATE VIEW AdminEmployeeOverview AS
SELECT
 EmployeeID,
 Title,
 Salary,
 DateOfHiring,
 WorkingHours
FROM Employee;
CREATE VIEW AdminCustomerOverview AS
SELECT
 CustomerID,
 Name,
 EmailAddress,
 Phone,
 DateOfBirth
FROM Customer;