-- Customer
INSERT INTO Customer (CustomerID, Phone, EmailAddress, Name, DateOfBirth) VALUES
(1, '05001112233', 'a1@mail.com', 'Ali Y�lmaz', '1990-05-01'),
(2, '05001112234', 'a2@mail.com', 'Ay�e Demir', '1988-08-12'),
(3, '05001112235', 'a3@mail.com', 'Mehmet Kara', '1979-11-23'),
(4, '05001112236', 'a4@mail.com', 'Elif Can', '1992-03-03'),
(5, '05001112237', 'a5@mail.com', 'Cem Y�ce', '1995-07-19'),
(6, '05001112238', 'a6@mail.com', 'Naz Y�ld�z', '1997-02-11'),
(7, '05001112239', 'a7@mail.com', 'Baran Aslan', '1985-06-30'),
(8, '05001112240', 'a8@mail.com', 'Sena Ayd�n', '1993-12-01'),
(9, '05001112241', 'a9@mail.com', 'Koray Bilgin', '1980-04-15'),
(10, '05001112242', 'a10@mail.com', 'Ezgi �en', '1991-09-10'),
(11, '05001112243', 'a11@mail.com', 'Arda G�ler', '1999-01-29'),
(12, '05001112244', 'a12@mail.com', 'Zeynep Ta�', '1996-11-17'),
(13, '05001112245', 'a13@mail.com', 'Burak Yurt', '1983-10-05'),
(14, '05001112246', 'a14@mail.com', 'Melis Dur', '1990-07-07'),
(15, '05001112247', 'a15@mail.com', 'Mert �z', '2001-06-06');

-- Room
INSERT INTO Room (RoomID, RoomStatus, Description, PricePerNight, RoomType) VALUES
(201, 'Available', 'Single Room with Garden View', 500.00, 'Single'),
(202, 'Occupied', 'Double Room with Balcony', 750.00, 'Double'),
(203, 'Available', 'Suite with Sea View', 1500.00, 'Suite'),
(204, 'Cleaning', 'Economy Room', 400.00, 'Economy'),
(205, 'Available', 'Standard Twin Room', 600.00, 'Twin'),
(206, 'Occupied', 'King Size Bed, City View', 1300.00, 'King'),
(207, 'Available', 'Penthouse Suite', 2000.00, 'Penthouse'),
(208, 'Available', 'Family Room with 3 Beds', 1000.00, 'Family'),
(209, 'Occupied', 'Double Room Ground Floor', 700.00, 'Double'),
(210, 'Maintenance', 'Old Style Room', 450.00, 'Classic'),
(211, 'Available', 'Corner Room', 800.00, 'Corner'),
(212, 'Occupied', 'Standard Room with Desk', 650.00, 'Standard'),
(213, 'Available', 'Studio Room', 550.00, 'Studio'),
(214, 'Available', 'Business Room', 900.00, 'Business'),
(215, 'Cleaning', 'Economy Room No View', 350.00, 'Economy');

-- Employee
INSERT INTO Employee (EmployeeID, Title, Salary, DateOfHiring, WorkingHours, ManagerID) VALUES
(1, 'Manager', 20000.00, '2020-01-01', '40', NULL),
(2, 'Receptionist', 12000.00, '2021-03-15', '40', 1),
(3, 'Receptionist', 11500.00, '2022-04-20', '38', 1),
(4, 'Housekeeper', 9000.00, '2023-01-01', '36', 1),
(5, 'Housekeeper', 8800.00, '2023-02-01', '36', 1),
(6, 'Chef', 15000.00, '2019-07-18', '45', 1),
(7, 'Waiter', 9500.00, '2020-09-09', '38', 6),
(8, 'Bartender', 10500.00, '2021-11-11', '38', 6),
(9, 'Security', 8000.00, '2022-06-10', '48', 1),
(10, 'Valet', 8200.00, '2022-07-10', '40', 1),
(11, 'Marketing', 11000.00, '2021-05-01', '40', 1),
(12, 'Receptionist', 11700.00, '2023-05-01', '36', 1),
(13, 'Housekeeper', 8700.00, '2023-03-01', '36', 1),
(14, 'Chef', 14900.00, '2021-10-01', '44', 1),
(15, 'Waiter', 9700.00, '2023-06-01', '40', 6);

-- Payment
INSERT INTO Payment (PaymentID, PaymentMethod, PaymentStatus, Amount, PaymentDate, CustomerID) VALUES
(1, 'Credit Card', 'Completed', 1000.00, '2025-05-20', 1),
(2, 'Cash', 'Completed', 750.00, '2025-05-21', 2),
(3, 'Credit Card', 'Pending', 1500.00, '2025-05-22', 3),
(4, 'Debit Card', 'Completed', 400.00, '2025-05-23', 4),
(5, 'Cash', 'Completed', 600.00, '2025-05-24', 5),
(6, 'Credit Card', 'Failed', 1300.00, '2025-05-25', 6),
(7, 'Online', 'Completed', 2000.00, '2025-05-26', 7),
(8, 'Credit Card', 'Completed', 1000.00, '2025-05-27', 8),
(9, 'Cash', 'Completed', 700.00, '2025-05-28', 9),
(10, 'Online', 'Completed', 450.00, '2025-05-29', 10),
(11, 'Credit Card', 'Pending', 800.00, '2025-05-29', 11),
(12, 'Cash', 'Completed', 1000.00, '2025-05-30', 12),
(13, 'Credit Card', 'Completed', 650.00, '2025-05-31', 13),
(14, 'Online', 'Completed', 950.00, '2025-06-01', 14),
(15, 'Cash', 'Completed', 350.00, '2025-06-02', 15);

-- Reservation
INSERT INTO Reservation (ReservationID, ReservationStatus, NumberOfPeople, Date, PaymentID, RoomID, CustomerID) VALUES
(1, 'Active', 2, '2025-05-20', 1, 201, 1),
(2, 'Completed', 1, '2025-05-21', 2, 202, 2),
(3, 'Pending', 3, '2025-05-22', 3, 203, 3),
(4, 'Completed', 2, '2025-05-23', 4, 204, 4),
(5, 'Active', 4, '2025-05-24', 5, 205, 5),
(6, 'Cancelled', 1, '2025-05-25', 6, 206, 6),
(7, 'Completed', 2, '2025-05-26', 7, 207, 7),
(8, 'Active', 3, '2025-05-27', 8, 208, 8),
(9, 'Completed', 2, '2025-05-28', 9, 209, 9),
(10, 'Pending', 1, '2025-05-29', 10, 210, 10),
(11, 'Active', 2, '2025-05-29', 11, 211, 11),
(12, 'Completed', 2, '2025-05-30', 12, 212, 12),
(13, 'Active', 2, '2025-05-31', 13, 213, 13),
(14, 'Completed', 3, '2025-06-01', 14, 214, 14),
(15, 'Cancelled', 1, '2025-06-02', 15, 215, 15);

-- Feedback
INSERT INTO Feedback (ReservationID, DateOfFeedback, AnonymityStatus, ManagementResponse, Rating, Comments) VALUES
(1, '2025-05-21', 1, 'Thank you!', 5, 'Excellent service'),
(2, '2025-05-22', 0, 'We appreciate it.', 4, 'Nice room'),
(3, '2025-05-23', 1, 'Will work on breakfast.', 3, 'Breakfast can improve'),
(4, '2025-05-24', 0, 'Thank you.', 5, 'Very clean'),
(5, '2025-05-25', 1, 'Thank you for staying.', 4, 'Staff was friendly'),
(6, '2025-05-26', 0, 'Sorry for the inconvenience.', 2, 'Noise issues'),
(7, '2025-05-27', 1, 'Glad you liked it!', 5, 'Perfect!'),
(8, '2025-05-28', 0, 'Thank you.', 3, 'Average experience'),
(9, '2025-05-29', 1, 'Hope to see you again.', 4, 'Good overall'),
(10, '2025-05-30', 0, 'Working on improvements.', 3, 'Mediocre bed'),
(11, '2025-05-30', 1, 'Thanks!', 5, 'Amazing food'),
(12, '2025-05-31', 0, 'We apologize.', 1, 'Very late check-in'),
(13, '2025-06-01', 1, 'We�ll fix it.', 2, 'Bathroom dirty'),
(14, '2025-06-02', 0, 'Thanks for feedback.', 4, 'Nice location'),
(15, '2025-06-03', 1, 'Noted.', 3, 'Could be better');


-- Organize
INSERT INTO Organize (ReservationID, EmployeeID) VALUES
(1, 2), (2, 3), (3, 2), (4, 4), (5, 4), (6, 5), (7, 2), (8, 3),
(9, 12), (10, 2), (11, 12), (12, 3), (13, 4), (14, 2), (15, 12);

-- HasAccess
INSERT INTO HasAccess (RoomID, EmployeeID) VALUES
(201, 4), (202, 4), (203, 5), (204, 5), (205, 4), (206, 5), (207, 5),
(208, 4), (209, 4), (210, 5), (211, 4), (212, 4), (213, 5), (214, 5), (215, 5);
