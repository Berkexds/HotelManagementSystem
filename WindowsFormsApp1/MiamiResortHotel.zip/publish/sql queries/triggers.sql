--With this trigger, we set the room reserved when a reservation is made for that room. That
excludes the room from reservation system.
CREATE TRIGGER trg_SetRoomReserved
ON Reservation
AFTER INSERT
AS
BEGIN
 UPDATE Room
 SET RoomStatus = 'Reserved'
 FROM Room r
 JOIN inserted i ON r.RoomID = i.RoomID;
END;
--With this trigger, we make the room which was set to reserved available once again after
the reservation status is marked completed. We do it as an update trigger because we want to
have our reservation records in our database even after they end.
CREATE TRIGGER trg_MakeRoomAvailableOnCompletion
ON Reservation
AFTER UPDATE
AS
BEGIN
 UPDATE Room
 SET RoomStatus = 'Available'
 FROM Room r
 JOIN inserted i ON r.RoomID = i.RoomID
 JOIN deleted d ON d.ReservationID = i.ReservationID
 WHERE i.ReservationStatus = 'Completed'
 AND d.ReservationStatus != 'Completed';
END;
--To automatically set payments for reservations to paid, we use the manual paying process
and check the nullity of payment method.
CREATE TRIGGER trg_SetPaidIfMethodExists
ON Payment
AFTER INSERT
AS
BEGIN
 UPDATE Payment
 SET PaymentStatus = 'Paid'
 FROM Payment p
 JOIN inserted i ON p.PaymentID = i.PaymentID
 WHERE (i.PaymentMethod IS NOT NULL AND i.PaymentMethod <> '');
END;